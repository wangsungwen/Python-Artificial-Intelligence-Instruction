"""Verify the installed classroom environment without opening a GUI."""
import sys
import tkinter
import ipykernel
import ipywidgets
import pandas
from zoneinfo import ZoneInfo

assert sys.version_info[:3] == (3, 10, 11), sys.version
print(sys.executable)
print(ZoneInfo("Asia/Taipei"))
print("IMPORT CHECK OK")

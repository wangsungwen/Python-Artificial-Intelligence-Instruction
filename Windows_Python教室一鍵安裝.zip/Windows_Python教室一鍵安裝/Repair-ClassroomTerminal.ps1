﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'
$base = Join-Path $env:LOCALAPPDATA 'PythonClassroom310'
$venv = Join-Path $base 'venv'
$activate = Join-Path $venv 'Scripts\activate.bat'
if (-not (Test-Path -LiteralPath $activate)) { throw '請先完成課程環境安裝。' }
$settingsFile = Join-Path $base 'VSCodeData\User\settings.json'
$workspaceFile = Join-Path $env:USERPROFILE 'PythonClassroom\PythonClassroom.code-workspace'
function Set-Property($Object, [string]$Name, $Value) {
    $Object | Add-Member -MemberType NoteProperty -Name $Name -Value $Value -Force
}
foreach ($file in @($settingsFile, $workspaceFile)) {
    if (-not (Test-Path -LiteralPath $file)) { continue }
    $document = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
    $settings = $document
    if ($file -eq $workspaceFile) {
        if (-not $document.settings) { Set-Property $document 'settings' ([pscustomobject]@{}) }
        $settings = $document.settings
    }
    Copy-Item -LiteralPath $file -Destination ($file + '.backup-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff'))
    Set-Property $settings 'python.terminal.activateEnvironment' $true
    Set-Property $settings 'python-envs.terminal.autoActivationType' 'command'
    Set-Property $settings 'python.defaultInterpreterPath' (Join-Path $venv 'Scripts\python.exe')
    # 移除舊安裝器預先填入的 PATH/VIRTUAL_ENV；改由 activate.bat 正式啟用。
    $envSettings = $settings.'terminal.integrated.env.windows'
    if ($envSettings) {
        if ($envSettings.VIRTUAL_ENV -eq $venv) {
            $envSettings.PSObject.Properties.Remove('VIRTUAL_ENV')
            if ($envSettings.PATH -and $envSettings.PATH.StartsWith((Join-Path $venv 'Scripts') + ';', [StringComparison]::OrdinalIgnoreCase)) {
                $envSettings.PSObject.Properties.Remove('PATH')
            }
        }
    }
    $profiles = $settings.'terminal.integrated.profiles.windows'
    if (-not $profiles) { $profiles = [pscustomobject]@{} }
    Set-Property $profiles 'Python Classroom (venv)' ([pscustomobject]@{
        path = "${env:SystemRoot}\System32\cmd.exe"
        args = @('/d', '/k', $activate)
    })
    Set-Property $settings 'terminal.integrated.profiles.windows' $profiles
    Set-Property $settings 'terminal.integrated.defaultProfile.windows' 'Python Classroom (venv)'
    [IO.File]::WriteAllText($file, ($document | ConvertTo-Json -Depth 30), (New-Object Text.UTF8Encoding($false)))
}
Write-Host '已修正課程終端機設定。請關閉舊終端機，再新增終端機；必要時重新開啟課程視窗。'

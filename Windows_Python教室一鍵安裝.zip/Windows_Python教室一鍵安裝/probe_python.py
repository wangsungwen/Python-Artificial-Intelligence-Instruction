"""Read-only version probe; file-based to support Windows PowerShell 5.1."""
import struct
import sys

print("%s|%s" % (".".join(map(str, sys.version_info[:3])), struct.calcsize("P") * 8))

@echo off
setlocal
title Python Classroom Installer
echo Python 3.10.11 + VS Code + Traditional Chinese
echo Please keep this window open until installation finishes.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-PythonClassroom.ps1" %*
set "INSTALL_RESULT=%ERRORLEVEL%"
echo.
if "%INSTALL_RESULT%"=="0" (echo Completed successfully.) else (echo Installation failed. Please read the messages above.)
pause
exit /b %INSTALL_RESULT%

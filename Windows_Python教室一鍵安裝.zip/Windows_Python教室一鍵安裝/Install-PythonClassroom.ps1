﻿#requires -Version 5.1
[CmdletBinding()]
param([switch]$CheckOnly)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
# 統一 Python 與 PowerShell 的原生程式輸出編碼，讓繁體中文驗證訊息可讀。
$env:PYTHONIOENCODING = 'utf-8'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# 僅安裝目前帳號；不提升權限、不修改永久 ExecutionPolicy。
$Base = Join-Path $env:LOCALAPPDATA 'PythonClassroom310'
$Work = Join-Path $env:USERPROFILE 'PythonClassroom'
$Cache = Join-Path $Base 'Downloads'
$Logs = Join-Path $Base 'Logs'
$Data = Join-Path $Base 'VSCodeData'
$Extensions = Join-Path $Base 'Extensions'
$Venv = Join-Path $Base 'venv'
$VenvPython = Join-Path $Venv 'Scripts\python.exe'
$ExtensionIds = @('ms-python.python', 'ms-python.vscode-pylance', 'ms-python.debugpy',
    'ms-toolsai.jupyter', 'MS-CEINTL.vscode-language-pack-zh-hant')
$TranscriptStarted = $false

function Write-Utf8([string]$Path, [string]$Text) {
    [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding($false)))
}
function Invoke-Checked([string]$Program, [string[]]$Arguments) {
    # Windows PowerShell 5.1 會將原生 stderr 包成 ErrorRecord；先收完訊息再判斷退出碼。
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $Program @Arguments 2>&1 | ForEach-Object { Write-Host "$_" }
        $resultCode = $LASTEXITCODE
    } finally { $ErrorActionPreference = $savedPreference }
    if ($resultCode -ne 0) { throw "$Program 執行失敗，結束代碼 $resultCode" }
}
function Get-PythonVersion([string]$Exe) {
    if (-not (Test-Path -LiteralPath $Exe)) { return '' }
    # 使用 .py 檔，避免 PS 5.1 傳遞 -c 字串時移除 Python 的雙引號。
    $probe = Join-Path $PSScriptRoot 'probe_python.py'
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $v = @(& $Exe -I $probe 2>&1)
        $resultCode = $LASTEXITCODE
    } finally { $ErrorActionPreference = $savedPreference }
    if ($resultCode -ne 0) { throw "Python 版本檢查失敗：$Exe`n$($v -join "`n")" }
    return ($v -join "`n").Trim()
}
function Get-SignedInstaller([string]$Url, [string]$File, [string]$Publisher) {
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            if (-not (Test-Path -LiteralPath $File)) {
                Write-Host "下載：$Url"
                Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile "$File.partial" -TimeoutSec 600
                Move-Item -LiteralPath "$File.partial" -Destination $File -Force
            }
            $sig = Get-AuthenticodeSignature -LiteralPath $File
            if ($sig.Status -ne 'Valid' -or $null -eq $sig.SignerCertificate -or
                $sig.SignerCertificate.Subject -notmatch $Publisher) {
                throw "安裝檔簽章或發行者不符：$File ($($sig.Status))"
            }
            Write-Host "簽章驗證通過；SHA256：$((Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash)"
            return
        } catch {
            if (Test-Path -LiteralPath $File) { Remove-Item -LiteralPath $File -Force }
            if (Test-Path -LiteralPath "$File.partial") { Remove-Item -LiteralPath "$File.partial" -Force }
            if ($attempt -eq 3) { throw }
            Write-Warning "下載／驗證失敗，準備重試：$($_.Exception.Message)"
            Start-Sleep -Seconds 3
        }
    }
}
function Run-Installer([string]$File, [string[]]$Arguments) {
    $p = Start-Process -FilePath $File -ArgumentList $Arguments -WindowStyle Hidden -Wait -PassThru
    if ($p.ExitCode -eq 3010) { Write-Warning '安裝程式建議重新開機；請於完成後重新開機。' }
    elseif ($p.ExitCode -ne 0) { throw "安裝程式失敗，代碼 $($p.ExitCode)。請查看 $Logs" }
}
function Get-VSCodeCli([string]$CodeExe) {
    $root = Split-Path $CodeExe
    $launcher = Join-Path $root 'bin\code.cmd'
    # 官方啟動器記錄目前版本路徑；新版可能把 resources 放在版本子目錄。
    if (Test-Path -LiteralPath $launcher) {
        $content = [IO.File]::ReadAllText($launcher)
        $match = [regex]::Match($content, '"%~dp0(?<relative>[^"\r\n]+cli\.js)"', 'IgnoreCase')
        if ($match.Success) {
            $path = [IO.Path]::GetFullPath((Join-Path (Split-Path $launcher) $match.Groups['relative'].Value))
            $prefix = [IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
            if ($path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -and
                (Test-Path -LiteralPath $path)) { return $path }
        }
    }
    $legacy = Join-Path $root 'resources\app\out\cli.js'
    if (Test-Path -LiteralPath $legacy) { return $legacy }
    throw "找不到可用的 VS Code CLI。已檢查官方啟動器 $launcher 與傳統路徑 $legacy。"
}

try {
    $os = Get-CimInstance Win32_OperatingSystem
    $arch = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
    if ([version]$os.Version -lt [version]'10.0' -or $os.ProductType -ne 1 -or $arch -ne 'AMD64') {
        throw '本安裝包適用 Windows 10／11 的 Intel/AMD 64 位元電腦，不適用 32 位元、ARM 或 Windows Server。'
    }
    Write-Host "作業系統：$($os.Caption)；目前帳號：$env:USERNAME"
    Write-Host '目標：Python 3.10.11 x64 + VS Code 穩定版 + Python/Jupyter + 繁體中文'
    if ($CheckOnly) {
        Write-Host "檢查通過；未下載、未安裝、未修改檔案。安裝位置：$Base"
        exit 0
    }
    foreach ($dir in @($Base,$Cache,$Logs,$Data,$Extensions,$Work)) {
        [void][IO.Directory]::CreateDirectory($dir)
    }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    Start-Transcript -Path (Join-Path $Logs "Install-$stamp.log") | Out-Null
    $TranscriptStarted = $true

    Write-Host '[1/6] 檢查與安裝 Python 3.10.11'
    $Target = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python310'
    $Python = Join-Path $Target 'python.exe'
    # Python 的相同 minor 版本共用安裝註冊項；避免覆蓋其他 3.10 修訂版。
    $Candidates = @($Python)
    foreach ($key in @('HKCU:\Software\Python\PythonCore\3.10\InstallPath',
                       'HKLM:\Software\Python\PythonCore\3.10\InstallPath')) {
        if (Test-Path $key) {
            $p = (Get-Item $key).GetValue('')
            if ($p) { $Candidates += Join-Path $p 'python.exe' }
        }
    }
    $Found = $false
    foreach ($candidate in ($Candidates | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $candidate) {
            $version = Get-PythonVersion $candidate
            if ($version -eq '3.10.11|64') { $Python = $candidate; $Found = $true; break }
            throw "已有不同或無法執行的 Python 3.10：$candidate ($version)。為避免降版覆蓋，請由管理員處理後重跑。"
        }
    }
    if (-not $Found) {
        $installer = Join-Path $Cache 'python-3.10.11-amd64.exe'
        Get-SignedInstaller 'https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe' $installer 'Python Software Foundation'
        Run-Installer $installer @('/quiet','InstallAllUsers=0',"TargetDir=`"$Target`"",'PrependPath=1',
            'Include_pip=1','Include_tcltk=1','Include_test=0','Include_launcher=0','Shortcuts=1',
            '/log',"`"$(Join-Path $Logs "Python-$stamp.log")`"")
    }
    if ((Get-PythonVersion $Python) -ne '3.10.11|64') { throw 'Python 安裝後版本驗證失敗。' }

    Write-Host '[2/6] 檢查與安裝 VS Code'
    $Code = Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\Code.exe'
    $SystemCode = Join-Path $env:ProgramFiles 'Microsoft VS Code\Code.exe'
    if (-not (Test-Path -LiteralPath $Code) -and (Test-Path -LiteralPath $SystemCode)) { $Code = $SystemCode }
    if (-not (Test-Path -LiteralPath $Code)) {
        $installer = Join-Path $Cache 'VSCodeUserSetup-x64.exe'
        Get-SignedInstaller 'https://update.code.visualstudio.com/latest/win32-x64-user/stable' $installer 'Microsoft Corporation'
        Run-Installer $installer @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART','/SP-',
            '/MERGETASKS="addtopath,!runcode"',"/LOG=`"$(Join-Path $Logs "VSCode-$stamp.log")`"")
    }
    if (-not (Test-Path -LiteralPath $Code)) { throw '找不到 VS Code 執行檔。' }
    # 直接呼叫 VS Code 官方 CLI JavaScript，避免 code.cmd 對含特殊字元路徑的二次解析。
    $Cli = Get-VSCodeCli $Code
    Write-Host "VS Code CLI：$Cli"
    $OldElectron = $env:ELECTRON_RUN_AS_NODE
    try {
        $env:ELECTRON_RUN_AS_NODE = '1'
        $Common = @($Cli,'--user-data-dir',$Data,'--extensions-dir',$Extensions,'--locale','zh-tw')
        Write-Host '[3/6] 安裝 Python、Pylance、Debugger、Jupyter 與繁體中文延伸套件'
        foreach ($id in $ExtensionIds) {
            Invoke-Checked $Code ($Common + @('--install-extension',$id))
        }
        # PS 5.1 對 GUI 子系統的 Code.exe 必須接輸出管線，才能等待並取得 CLI 輸出。
        $installedText = & $Code @Common --list-extensions | Out-String
        if ($LASTEXITCODE -ne 0) { throw '無法驗證延伸套件清單。' }
        $installed = @($installedText -split '\r?\n' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        foreach ($id in $ExtensionIds) {
            if ($installed -notcontains $id) { throw "延伸套件未安裝完成：$id" }
        }
        & $Code @Common --list-extensions --show-versions | Out-File (Join-Path $Logs "Extensions-$stamp.txt") -Encoding utf8
    } finally { $env:ELECTRON_RUN_AS_NODE = $OldElectron }

    Write-Host '[4/6] 建立課程虛擬環境與 Notebook 所需套件'
    if (-not (Test-Path -LiteralPath $VenvPython)) { Invoke-Checked $Python @('-m','venv',$Venv) }
    if ((Get-PythonVersion $VenvPython) -ne '3.10.11|64') { throw '課程虛擬環境版本不符，請勿混用其他 Python。' }
    Invoke-Checked $VenvPython @('-m','pip','install','--upgrade','pip','--disable-pip-version-check')
    Invoke-Checked $VenvPython @('-m','pip','install','--only-binary=:all:','--disable-pip-version-check',
        'ipykernel','ipywidgets','pandas','tzdata')
    Invoke-Checked $VenvPython @('-m','pip','check')
    Invoke-Checked $VenvPython @('-m','ipykernel','install','--user','--name','python-classroom-310',
        '--display-name','Python 3.10.11 (Classroom)')

    Write-Host '[5/6] 設定繁體中文課程工作區與桌面捷徑'
    # 獨立的課程使用者資料夾：不覆蓋原 VS Code 的 settings.json / argv.json。
    $settingsDir = Join-Path $Data 'User'
    [void][IO.Directory]::CreateDirectory($settingsDir)
    $settingsPath = Join-Path $settingsDir 'settings.json'
    if (-not (Test-Path -LiteralPath $settingsPath)) {
        $settings = @{
            'python.defaultInterpreterPath' = $VenvPython
            'python.terminal.activateEnvironment' = $true
            'python-envs.terminal.autoActivationType' = 'command'
            'terminal.integrated.defaultProfile.windows' = 'Command Prompt'
            'editor.fontSize' = 16
            'editor.tabSize' = 4
            'files.encoding' = 'utf8'
        }
        Write-Utf8 $settingsPath ($settings | ConvertTo-Json -Depth 6)
    }
    $workspace = Join-Path $Work 'PythonClassroom.code-workspace'
    if (-not (Test-Path -LiteralPath $workspace)) {
        Write-Utf8 $workspace (@{folders=@(@{path='.'});settings=@{'python.defaultInterpreterPath'=$VenvPython}} | ConvertTo-Json -Depth 5)
    }
    Invoke-Checked "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'Repair-ClassroomTerminal.ps1'))
    $hello = Join-Path $Work 'hello_classroom.py'
    if (-not (Test-Path -LiteralPath $hello)) {
        Write-Utf8 $hello "import sys`nprint('Python 教室安裝成功！')`nprint(sys.version)`nfor i in range(1, 4):`n    print(f'第 {i} 次練習：{i} + 2 = {i + 2}')`n"
    }
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Python 教室（繁體中文）.lnk'))
    $link.TargetPath = $Code
    $link.Arguments = "--user-data-dir `"$Data`" --extensions-dir `"$Extensions`" --locale zh-tw `"$workspace`""
    $link.WorkingDirectory = $Work
    $link.IconLocation = "$Code,0"
    $link.Save()

    Write-Host '[6/6] 驗證 Python、Tkinter、Notebook、套件及時區'
    Invoke-Checked $VenvPython @('-I',(Join-Path $PSScriptRoot 'verify_classroom.py'))
    Invoke-Checked $VenvPython @($hello)
    & $VenvPython -m pip freeze | Out-File (Join-Path $Logs "Packages-$stamp.txt") -Encoding utf8
    Write-Host "`n安裝完成！請開啟桌面「Python 教室（繁體中文）」。" -ForegroundColor Green
    Write-Host 'Notebook 右上角選取核心：Python 3.10.11 (Classroom)。F5 可啟動 Python 偵錯。'
    Write-Host "課程檔案：$Work`n安裝紀錄：$Logs"
    exit 0
} catch {
    Write-Host "`n安裝未完成：$($_.Exception.Message)" -ForegroundColor Red
    Write-Host "請查看紀錄：$Logs；處理網路、權限或版本問題後，可重新執行。"
    exit 1
} finally {
    if ($TranscriptStarted) { Stop-Transcript | Out-Null }
}
